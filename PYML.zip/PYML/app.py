import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score

# =============================
# PAGE CONFIG
# =============================
st.set_page_config(page_title="Cybersecurity Analytics Platform", layout="wide")

# =============================
# LOAD DATA
# =============================
@st.cache_data
def load_data():
    df = pd.read_csv("cybersecurity_clean_project_10000_rows.csv")
    df["report_date"] = pd.to_datetime(df["report_date"])
    df["Year"] = df["report_date"].dt.year
    return df

df = load_data()

# =============================
# SIDEBAR NAVIGATION
# =============================
st.sidebar.title("🔐 Navigation")

page = st.sidebar.radio(
    "Go To",
    ["Dashboard", "Threat Trends", "Prediction", "Advanced Analytics", "Global Map"]
)

# =============================
# DASHBOARD
# =============================
if page == "Dashboard":

    st.title("📊 Cybersecurity Dashboard")

    st.sidebar.subheader("Filters")

    industry = st.sidebar.multiselect(
        "Industry",
        df["industry"].unique(),
        default=df["industry"].unique()
    )

    attack = st.sidebar.multiselect(
        "Attack Type",
        df["attack_type"].unique(),
        default=df["attack_type"].unique()
    )

    severity = st.sidebar.multiselect(
        "Severity Level",
        df["severity_level"].unique(),
        default=df["severity_level"].unique()
    )

    filtered_df = df[
        (df["industry"].isin(industry)) &
        (df["attack_type"].isin(attack)) &
        (df["severity_level"].isin(severity))
    ]

    st.subheader("📌 Key Metrics")

    col1, col2, col3, col4 = st.columns(4)

    col1.metric("Total Incidents", len(filtered_df))
    col2.metric("Avg Financial Loss",
                f"${filtered_df['financial_loss_usd'].mean():,.0f}")
    total_records = filtered_df['records_exposed'].sum() / 1_000_000

    col3.metric(
        "Total Records Exposed",
        f"{total_records:,.2f} M"
    )
    col4.metric("Avg Recovery Cost",
                f"${filtered_df['recovery_cost_usd'].mean():,.0f}")

    st.divider()

    c1, c2 = st.columns(2)

    with c1:
        st.subheader("💰 Financial Loss Distribution")

        fig1, ax1 = plt.subplots(figsize=(6,4))

        sns.histplot(
            filtered_df["financial_loss_usd"],
            bins=40,
            kde=True,
            color="skyblue",
            ax=ax1
        )

        ax1.set_title("Distribution of Financial Loss", fontsize=12)
        ax1.set_xlabel("Financial Loss (USD)")
        ax1.set_ylabel("Number of Incidents")
        ax1.grid(alpha=0.3)

        plt.tight_layout()
        st.pyplot(fig1)
    with c2:
        st.subheader("🛡 Attack Type Distribution")

        fig2, ax2 = plt.subplots(figsize=(6,4))

        attack_counts = filtered_df["attack_type"].value_counts()

        bars = ax2.bar(attack_counts.index, attack_counts.values, color="teal")

        ax2.set_title("Number of Incidents by Attack Type")
        ax2.set_xlabel("Attack Type")
        ax2.set_ylabel("Count")
        ax2.tick_params(axis='x', rotation=45)

        # Add value labels
        for bar in bars:
            height = bar.get_height()
            ax2.text(
                bar.get_x() + bar.get_width()/2,
                height,
                f'{int(height)}',
                ha='center',
                va='bottom'
            )

        ax2.grid(axis="y", alpha=0.3)
        plt.tight_layout()
        st.pyplot(fig2)

    c3, c4 = st.columns(2)

    with c3:
        st.subheader("🏢 Industry Avg Loss")

        industry_loss = filtered_df.groupby("industry")["financial_loss_usd"].mean().sort_values()

        fig3, ax3 = plt.subplots(figsize=(6,4))

        bars = ax3.barh(industry_loss.index, industry_loss.values, color="orange")

        ax3.set_title("Average Financial Loss by Industry")
        ax3.set_xlabel("Average Loss (USD)")
        ax3.set_ylabel("Industry")

        # Add value labels
        for bar in bars:
            width = bar.get_width()
            ax3.text(
                width,
                bar.get_y() + bar.get_height()/2,
                f'${width:,.0f}',
                va='center'
            )

        ax3.grid(axis="x", alpha=0.3)
        plt.tight_layout()
        st.pyplot(fig3)

    with c4:
        st.subheader("📈 Yearly Financial Loss Trend")

        yearly = filtered_df.groupby("Year")["financial_loss_usd"].mean()

        fig4, ax4 = plt.subplots(figsize=(6,4))

        ax4.plot(yearly.index, yearly.values, marker="o", linewidth=2)

        ax4.set_title("Average Financial Loss Over Years")
        ax4.set_xlabel("Year")
        ax4.set_ylabel("Average Loss (USD)")
        ax4.grid(alpha=0.3)

        # Add data labels
        for x, y in zip(yearly.index, yearly.values):
            ax4.text(x, y, f'${y:,.0f}', ha='center', va='bottom')

        plt.tight_layout()
        st.pyplot(fig4)
# =============================
# THREAT TRENDS
# =============================
elif page == "Threat Trends":

    st.title("📈 Threat Intelligence Trends")

    st.subheader("Average Financial Loss Over Years")
    st.line_chart(df.groupby("Year")["financial_loss_usd"].mean())

    st.subheader("Attack Type Frequency")
    st.bar_chart(df["attack_type"].value_counts())

    st.subheader("Total Records Exposed Over Years")
    st.area_chart(df.groupby("Year")["records_exposed"].sum())

# =============================
# PREDICTION
# =============================
elif page == "Prediction":

    st.title("🤖 Financial Loss Prediction")

    y = df["financial_loss_usd"]
    X = df.drop(["financial_loss_usd", "incident_id", "report_date"], axis=1)
    X = pd.get_dummies(X, drop_first=True)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    @st.cache_resource
    def train_model():
        model = RandomForestRegressor(
            n_estimators=200,
            max_depth=20,
            random_state=42
        )
        model.fit(X_train, y_train)
        return model

    model = train_model()

    st.metric("Model R² Score", round(r2_score(y_test, model.predict(X_test)), 3))

    # =============================
    # USER INPUT SECTION
    # =============================

    st.subheader("Enter Incident Details")

    col1, col2 = st.columns(2)

    with col1:
        affected_systems = st.number_input("Affected Systems", 0, 10000, 50)
        affected_users = st.number_input("Affected Users", 0, 100000, 500)
        records_exposed = st.number_input("Records Exposed", 0, 1000000, 1000)

    with col2:
        recovery_cost_usd = st.number_input("Recovery Cost (USD)", 0.0, 500000.0, 20000.0)
        response_time_hours = st.number_input("Response Time (Hours)", 0.0, 100.0, 10.0)
        detection_time_hours = st.number_input("Detection Time (Hours)", 0.0, 100.0, 5.0)

    if st.button("Predict Financial Loss"):

        input_data = {
            "affected_systems": affected_systems,
            "affected_users": affected_users,
            "records_exposed": records_exposed,
            "recovery_cost_usd": recovery_cost_usd,
            "response_time_hours": response_time_hours,
            "detection_time_hours": detection_time_hours,
        }

        input_df = pd.DataFrame([input_data])

        for col in X.columns:
            if col not in input_df.columns:
                input_df[col] = 0

        input_df = input_df[X.columns]

        prediction = model.predict(input_df)[0]

        st.success(f"💰 Estimated Financial Loss: ${prediction:,.2f}")

# =============================
# ADVANCED ANALYTICS
# =============================
elif page == "Advanced Analytics":

    st.title("📊 Advanced Cybersecurity Analytics")

    st.sidebar.subheader("📅 Filter")

    selected_years = st.sidebar.multiselect(
        "Select Year",
        sorted(df["Year"].unique()),
        default=sorted(df["Year"].unique())
    )

    filtered_df = df[df["Year"].isin(selected_years)]

    if filtered_df.empty:
        st.warning("No data available for selected year.")
        st.stop()

    st.divider()

    # =============================
    # ROW 1
    # =============================
    col1, col2 = st.columns(2)

    with col1:
        st.subheader("🎻 Financial Loss by Severity")

        fig1, ax1 = plt.subplots(figsize=(5,4))

        sns.violinplot(
            x="severity_level",
            y="financial_loss_usd",
            data=filtered_df,
            palette="coolwarm",
            ax=ax1
        )

        ax1.set_xlabel("Severity Level")
        ax1.set_ylabel("Financial Loss (USD)")
        ax1.set_title("Loss Distribution by Severity")

        st.pyplot(fig1)
        plt.close(fig1)

    with col2:
        st.subheader("📉 Records vs Financial Loss")

        fig2, ax2 = plt.subplots(figsize=(5,4))

        sns.scatterplot(
            x="records_exposed",
            y="financial_loss_usd",
            data=filtered_df,
            alpha=0.6,
            ax=ax2
        )

        ax2.set_xlabel("Records Exposed")
        ax2.set_ylabel("Financial Loss (USD)")
        ax2.set_title("Records Exposed vs Financial Loss")

        st.pyplot(fig2)
        plt.close(fig2)

    st.divider()

    # =============================
    # ROW 2
    # =============================
    col3, col4 = st.columns(2)

    with col3:
        st.subheader("🔍 Feature Correlation")

        numeric_df = filtered_df.select_dtypes(include=["int64", "float64"])

        fig3, ax3 = plt.subplots(figsize=(5,4))

        sns.heatmap(
            numeric_df.corr(),
            annot=True,
            cmap="coolwarm",
            fmt=".2f",
            cbar=False,
            ax=ax3
        )

        ax3.set_title("Correlation Matrix")

        st.pyplot(fig3)
        plt.close(fig3)

    with col4:
        st.subheader("📦 Financial Loss by Attack Type")

        fig4, ax4 = plt.subplots(figsize=(5,4))

        sns.boxplot(
            x="attack_type",
            y="financial_loss_usd",
            data=filtered_df,
            ax=ax4
        )

        ax4.set_xlabel("Attack Type")
        ax4.set_ylabel("Financial Loss (USD)")
        ax4.set_title("Loss by Attack Type")
        ax4.tick_params(axis='x', rotation=45)

        st.pyplot(fig4)
        plt.close(fig4)
# =============================
# GLOBAL MAP
# =============================
elif page == "Global Map":

    st.title("🌍 Global Cybersecurity Incident Map")

    country_data = (
        df.groupby("country")
        .agg(
            total_incidents=("incident_id", "count"),
            total_loss=("financial_loss_usd", "sum"),
            total_records=("records_exposed", "sum")
        )
        .reset_index()
    )

    metric = st.selectbox(
        "Select Metric",
        ["total_incidents", "total_loss", "total_records"]
    )

    fig = px.choropleth(
        country_data,
        locations="country",
        locationmode="country names",
        color=metric,
        hover_name="country",
        color_continuous_scale="Reds",
        template="plotly_dark"
    )

    fig.update_layout(height=600)

    st.plotly_chart(fig, use_container_width=True)
